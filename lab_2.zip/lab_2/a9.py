import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler, StandardScaler

def load_thyroid_data(file_path):
    return pd.read_excel(file_path, sheet_name="thyroid0387_UCI")

def identify_numeric_columns(df):
    cols = df.select_dtypes(include=["int64", "float64"]).columns.tolist()
    cols = [col for col in cols if "id" not in col.lower()]
    return cols

def apply_minmax_scaling(df, numeric_cols):
    scaler = MinMaxScaler()
    scaled_df = df.copy()
    scaled_df[numeric_cols] = scaler.fit_transform(df[numeric_cols])
    return scaled_df

def apply_zscore_scaling(df, numeric_cols):
    scaler = StandardScaler()
    scaled_df = df.copy()
    scaled_df[numeric_cols] = scaler.fit_transform(df[numeric_cols])
    return scaled_df

def main():
    file_path = r"C:\Users\kowsa\OneDrive\Desktop\ML\Lab_2\Copy of Lab Session Data.xlsx"

    df = load_thyroid_data(file_path)

    numeric_cols = identify_numeric_columns(df)

    minmax_df = apply_minmax_scaling(df, numeric_cols)
    zscore_df = apply_zscore_scaling(df, numeric_cols)

    print("\nA9 — DATA NORMALIZATION / SCALING")

    print("\nNumeric Attributes Identified for Normalization:")
    print(numeric_cols)

    print("\nOriginal Numeric Data Sample:")
    print(df[numeric_cols].head())

    print("\nMin-Max Normalized Data Sample:")
    print(minmax_df[numeric_cols].head())

    print("\nZ-Score Normalized Data Sample:")
    print(zscore_df[numeric_cols].head())

if __name__ == "__main__":
    main()
