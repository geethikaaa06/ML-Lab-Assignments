import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

def load_thyroid_data(file_path):
    return pd.read_excel(file_path, sheet_name="thyroid0387_UCI")

def get_first_20_vectors(df):
    return df.iloc[:20]

def convert_binary(df):
    binary_sets = [
        {0, 1}, {True, False}, {"t", "f"}, {"yes", "no"}, {"Y", "N"}
    ]

    binary_cols = []
    for col in df.columns:
        unique_vals = set(df[col].dropna().unique())
        if any(unique_vals.issubset(bset) for bset in binary_sets):
            binary_cols.append(col)

    mapping = {"t": 1, "f": 0, "yes": 1, "no": 0, "Y": 1, "N": 0, True: 1, False: 0}
    bin_df = df[binary_cols].replace(mapping).astype(int)

    return bin_df

def convert_numeric(df):
    return df.apply(lambda col: pd.factorize(col)[0])

def compute_jc_smc_matrix(bin_df):
    n = len(bin_df)
    JC = np.zeros((n, n))
    SMC = np.zeros((n, n))

    for i in range(n):
        for j in range(n):
            v1 = bin_df.iloc[i].values
            v2 = bin_df.iloc[j].values

            f11 = np.sum((v1 == 1) & (v2 == 1))
            f10 = np.sum((v1 == 1) & (v2 == 0))
            f01 = np.sum((v1 == 0) & (v2 == 1))
            f00 = np.sum((v1 == 0) & (v2 == 0))

            denom_jc = f11 + f10 + f01
            denom_smc = f11 + f10 + f01 + f00

            JC[i][j] = f11 / denom_jc if denom_jc != 0 else 0
            SMC[i][j] = (f11 + f00) / denom_smc if denom_smc != 0 else 0

    return JC, SMC

def compute_cosine_matrix(num_df):
    n = len(num_df)
    COS = np.zeros((n, n))

    for i in range(n):
        for j in range(n):
            v1 = num_df.iloc[i].values.astype(float)
            v2 = num_df.iloc[j].values.astype(float)

            if np.linalg.norm(v1) == 0:
                v1 = v1 + 1e-9
            if np.linalg.norm(v2) == 0:
                v2 = v2 + 1e-9

            COS[i][j] = np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2))

    return COS

def plot_heatmap(matrix, title):
    sns.heatmap(matrix, annot=True, cmap="coolwarm")
    plt.title(title)
    plt.show()

def main():
    file_path = r"C:\Users\saige\Downloads\Lab Session Data.xlsx"

    df = load_thyroid_data(file_path)

    first20 = get_first_20_vectors(df)

    bin_df = convert_binary(first20)
    num_df = convert_numeric(first20)

    JC, SMC = compute_jc_smc_matrix(bin_df)
    COS = compute_cosine_matrix(num_df)

    print("\nA7 — HEATMAP SIMILARITY MATRICES")
    print("\nJC Matrix:\n", JC)
    print("\nSMC Matrix:\n", SMC)
    print("\nCOS Matrix:\n", COS)

    plot_heatmap(JC, "Jaccard Coefficient Heatmap")
    plot_heatmap(SMC, "Simple Matching Coefficient Heatmap")
    plot_heatmap(COS, "Cosine Similarity Heatmap")

if __name__ == "__main__":
    main()
