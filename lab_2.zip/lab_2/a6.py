import pandas as pd
import numpy as np

def load_thyroid_data(file_path):
    return pd.read_excel(file_path, sheet_name="thyroid0387_UCI")

def get_first_two_vectors(df):
    v1 = df.iloc[0]
    v2 = df.iloc[1]
    return v1, v2

def convert_to_numeric(v1, v2):
    combined = pd.concat([v1, v2], axis=1).T
    combined = combined.apply(lambda col: pd.factorize(col)[0])
    vec1 = combined.iloc[0].values.astype(float)
    vec2 = combined.iloc[1].values.astype(float)
    return vec1, vec2

def cosine_similarity(vec1, vec2):
    if np.linalg.norm(vec1) == 0:
        vec1 = vec1 + 1e-9
    if np.linalg.norm(vec2) == 0:
        vec2 = vec2 + 1e-9

    dot = np.dot(vec1, vec2)
    norm_a = np.linalg.norm(vec1)
    norm_b = np.linalg.norm(vec2)

    return dot / (norm_a * norm_b)

def main():
    file_path = r"C:\Users\saige\Downloads\Lab Session Data.xlsx"

    df = load_thyroid_data(file_path)

    v1, v2 = get_first_two_vectors(df)

    num_v1, num_v2 = convert_to_numeric(v1, v2)

    similarity = cosine_similarity(num_v1, num_v2)

    print("\nA6 — COSINE SIMILARITY MEASURE")

    print("\nComplete Feature Vector (Document A):")
    print(num_v1)

    print("\nComplete Feature Vector (Document B):")
    print(num_v2)

    print("\nCosine Similarity Value:", similarity)

    print("\nInterpretation:")
    print("Value close to 1 → Very Similar")
    print("Value close to 0 → Not Similar")
    print("Value close to -1 → Opposite")

if __name__ == "__main__":
    main()
