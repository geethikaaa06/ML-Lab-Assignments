import pandas as pd
import numpy as np
def load_purchase_data(file_path):
    df = pd.read_excel(file_path, sheet_name="Purchase data")
    X = df[["Candies (#)", "Mangoes (Kg)", "Milk Packets (#)"]].values
    y = df["Payment (Rs)"].values

    return X, y
def get_dimensionality(X):
    return X.shape[1]
def count_vectors(X):
    return X.shape[0]
def calculate_rank(X):
    return np.linalg.matrix_rank(X)
def compute_product_cost(X, y):
    X_pinv = np.linalg.pinv(X)
    cost = X_pinv @ y
    return cost
def main():
    file_path = r"C:\Users\saige\Downloads\Lab Session Data.xlsx"
    X, y = load_purchase_data(file_path)

    dimensionality = get_dimensionality(X)
    num_vectors = count_vectors(X)
    rank = calculate_rank(X)
    cost = compute_product_cost(X, y)

    print("Feature Matrix X:\n", X)
    print("Output Vector y:\n", y)

    print("\nDimensionality of Vector Space:", dimensionality)
    print("Number of Vectors in Space:", num_vectors)
    print("Rank of Feature Matrix:", rank)

    print("\nEstimated Cost of Each Product:")
    print("Candies Cost:", cost[0])
    print("Mangoes Cost:", cost[1])
    print("Milk Packets Cost:", cost[2])

if __name__ == "__main__":
    main()
